// ambil id
function welcome(){
    let btnWelcome = document.getElementById('welcome');
    let tampilan = document.getElementById('tampilan');
    tampilan.classList.toggle('hidden')
btnWelcome.classList.toggle('hidden')
}