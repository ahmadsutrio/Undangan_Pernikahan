<div class="flex  relative flex-col mt-10 justify-center  text-center text-paragraph text-sm font-poppins ">

    <p class="">Menjadi sebuah kebahagiaan bagi kami apabila bapak/ibu/saudara/i berkenan hadir dalam hari bahagia ini. Terimakasih, atas segala ucapan, doa, dan perhatian yang diberikan.</p>

    <p class="font-semibold mt-7">See you on our big day!</p>

    <div class="font-great-vebes gap-9 text-[2.7rem] mb-28 text-primary mx-auto size-96 -mt-9 relative flex justify-center items-center flex-col">
        <h4 class="">Rohmat</h4>
        <h4 class="">&</h4>
        <h4 class="">Putri</h4>
        <div class="absolute  ">
            <img src="/public/img/circle-border.png" alt="" class="">
        </div>
    </div>


    <div class="absolute left-0 right-0 bottom-0">
        <img src="../public/img/daun-bawah-footer.webp" alt="" class="w-full">
    </div>
</div>