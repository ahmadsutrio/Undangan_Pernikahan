<div class="px-10  flex flex-col relative w-full  h-[33rem] justify-center font-poppins bg-cover bg-center ">
    <div class="absolute top-0 left-0 right-0 bottom-0 flex justify-center -z-[1]">
        <img src="../public/img/pasir&bunga.webp" alt="" class="w-full">
    </div>
    <h4 class="text-[2rem] z-10 text-center text-paragraph font-semibold mb-3">Kotak Pesan</h4>
    <div class="flex flex-col gap-3 overflow-y-auto h-48 ">
        <div class="bg-white border rounded-lg p-3 flex flex-col text-paragraph flex-wrap">
            <h5 class="text-[1rem] font-semibold mb-1">Ahmad Sutrio Prihatinoto</h5>
            <p class="text-sm text-paragraph/80">Status Kehadiran : Hadir</p>
            <p class="text-sm text-paragraph/80">Pesan : Selamat untuk calon mempelai semoga dipermudah segalanya</p>
        </div>
        <div class="bg-white border rounded-lg p-3 flex flex-col text-paragraph flex-wrap">
            <h5 class="text-[1rem] font-semibold mb-1">Ahmad Sutrio Prihatinoto</h5>
            <p class="text-sm text-paragraph/80">Status Kehadiran : Hadir</p>
            <p class="text-sm text-paragraph/80">Pesan : Selamat untuk calon mempelai semoga dipermudah segalanya</p>
        </div>
        <div class="bg-white border rounded-lg p-3 flex flex-col text-paragraph flex-wrap">
            <h5 class="text-[1rem] font-semibold mb-1">Ahmad Sutrio Prihatinoto</h5>
            <p class="text-sm text-paragraph/80">Status Kehadiran : Hadir</p>
            <p class="text-sm text-paragraph/80">Pesan : Selamat untuk calon mempelai semoga dipermudah segalanya</p>
        </div>
        <div class="bg-white border rounded-lg p-3 flex flex-col text-paragraph flex-wrap">
            <h5 class="text-[1rem] font-semibold mb-1">Ahmad Sutrio Prihatinoto</h5>
            <p class="text-sm text-paragraph/80">Status Kehadiran : Hadir</p>
            <p class="text-sm text-paragraph/80">Pesan : Selamat untuk calon mempelai semoga dipermudah segalanya</p>
        </div>
        <div class="bg-white border rounded-lg p-3 flex flex-col text-paragraph flex-wrap">
            <h5 class="text-[1rem] font-semibold mb-1">Ahmad Sutrio Prihatinoto</h5>
            <p class="text-sm text-paragraph/80">Status Kehadiran : Hadir</p>
            <p class="text-sm text-paragraph/80">Pesan : Selamat untuk calon mempelai semoga dipermudah segalanya</p>
        </div>
    </div>
</div>